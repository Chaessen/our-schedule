package com.example.open_calander_junkyu_java3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.net.MalformedURLException;

import static java.sql.Types.NULL;

public class RegisterActivity extends AppCompatActivity {
    private EditText reg_ID, reg_PW, reg_Name, reg_Age;
    // String으로 받을 경우 회색 글씨
    private Button btn_register;
    private String reg1_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        NetworkUtil.setNetworkPolicy();

        reg_ID = (EditText)findViewById(R.id.register_etID);
        // reg_ID = ((EditText)findViewById(R.id.register_etID)).getText().toString();
        reg_PW = (EditText)findViewById(R.id.register_etPW);
        reg_Name = (EditText)findViewById(R.id.register_etName);
        reg_Age = (EditText)findViewById(R.id.register_etAge);
        btn_register = (Button)findViewById(R.id.register_btRegister);





        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(reg_ID.length() == 0 || reg_PW.length() == 0 || reg_Name.length() == 0 || reg_Age.length() == 0) {
                        // String일 경우 .trim() 바로 가능
                        Toast.makeText(getApplication(), "빈칸을 채워주세요.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    else {
                        PHPRequest request = new PHPRequest("http://133.186.229.67/Calander_Register.php");
                        String result = request.PhPregister(String.valueOf(reg_ID.getText()), String.valueOf(reg_PW.getText()), String.valueOf(reg_Name.getText()), String.valueOf(reg_Age.getText()));
                        if (result.equals("Input OK")) {
                            Toast.makeText(getApplication(), "회원가입 완료", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(getApplication(), "사용 불가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }catch (MalformedURLException e){
                    e.printStackTrace();
                }
            }
        });
    }
}