package com.example.open_calander_junkyu_java3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public String fname = null;
    public String str = null;
    public MaterialCalendarView calendarView;
    public Button cha_Btn, del_Btn, save_Btn, movetoNotice,btn_Get, start_time, end_time, time_set,reset_btn;
    public TextView diaryTextView, textView2, textView3, time_start, time_end;
    public EditText contextEditText;
    public int year;
    public int month;
    public int day;
    public int change;

    int sHour;
    int sMinute;
    int eHour;
    int eMinute;
    static final int TIME_DIALOG_ID = 1;

    private Animation btn_open, btn_close;
    private Boolean isBtnOpen = false;
    private FloatingActionButton OpenBtnList, MovetoBoard, MovetoPersonal, MovetoOpen;


    int alarmHour=0, alarmMinute;

    @SuppressLint("SetTextI18n")

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent intent = getIntent();
        String userName = intent.getStringExtra("userName");
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        calendarView = findViewById(R.id.calendarView);
        diaryTextView = findViewById(R.id.main_slot);
        save_Btn = findViewById(R.id.main_btSave);
        del_Btn = findViewById(R.id.main_btDel);
        cha_Btn = findViewById(R.id.main_btEdit);
        textView2 = findViewById(R.id.main_list);
        textView3 = findViewById(R.id.main_title);
        contextEditText = findViewById(R.id.main_context);

        start_time = findViewById(R.id.btn_start_time);
        end_time = findViewById(R.id.btn_end_time);

        time_start = findViewById(R.id.start_time);
        time_end = findViewById(R.id.end_time);
        reset_btn = findViewById(R.id.Invisible);
        time_set = findViewById(R.id.time_set);

        btn_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.openbutton);
        btn_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.closebutton);
        OpenBtnList = (FloatingActionButton) findViewById(R.id.OpenBtnList);
        MovetoBoard = (FloatingActionButton) findViewById(R.id.MovetoBoard);
        MovetoPersonal = (FloatingActionButton) findViewById(R.id.MovetoPersonal);
        MovetoOpen = (FloatingActionButton) findViewById(R.id.MovetoOpen);

        OpenBtnList.setOnClickListener(this);
        MovetoBoard.setOnClickListener(this);
        MovetoPersonal.setOnClickListener(this);
        MovetoOpen.setOnClickListener(this);

        final String userID = intent.getStringExtra("userID");
        textView3.setText(userName + "님의 캘린더");

        try {
            PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_Pickdot.php");
            String result_date = request.PhPCalenderGetDay(userName);
            JSONArray Dotarry = new JSONArray(result_date);
            for (int i = 0; i < Dotarry.length(); i++) {
                JSONObject DotObject = Dotarry.getJSONObject(i);
                int DotYear = DotObject.getInt("Year");
                int DotMonth = DotObject.getInt("Month");
                int DotDay = DotObject.getInt("Day");
                Log.d("pickdot", "Dotarry" + DotYear);
                calendarView.addDecorators(
                        new EventDecorator(Color.RED, Collections.singleton(CalendarDay.from(DotYear, DotMonth - 1, DotDay)))//오늘일자에 점 찍
                );//일정받아서 점 찍는거
            }
            calendarView.addDecorators(
                    new EventDecorator(Color.BLUE, Collections.singleton(CalendarDay.today()))
            );//일정받아서 점 찍는거
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        calendarView.addDecorators(
                new SundayDecorator(),
                new SaturdayDecorator()// 주말 색깔 적용
        );


        calendarView.setDynamicHeightEnabled(true);//  마지막주에 맞게 설정하기

        calendarView.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {
                year = date.getYear();
                month = date.getMonth();
                day = date.getDay();

                reset_btn.setVisibility(View.VISIBLE);
                diaryTextView.setVisibility(View.VISIBLE);
                save_Btn.setVisibility(View.VISIBLE);
                start_time.setVisibility((View.INVISIBLE));
                end_time.setVisibility((View.INVISIBLE));
                contextEditText.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.INVISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);
                diaryTextView.setText(String.format("%d / %d / %d", date.getYear(), date.getMonth() + 1, date.getDay()));
                contextEditText.setText("");
                checkDay(date.getYear(), date.getMonth(), date.getDay());
            }
        });
        reset_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_btn.setVisibility(View.INVISIBLE);
                diaryTextView.setVisibility(View.INVISIBLE);
                save_Btn.setVisibility(View.INVISIBLE);
                start_time.setVisibility((View.INVISIBLE));
                end_time.setVisibility((View.INVISIBLE));
                contextEditText.setVisibility(View.INVISIBLE);
                textView2.setVisibility(View.INVISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);
                time_set.setVisibility(View.INVISIBLE);
            }
        });
        save_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("checkDay", "onClicksave");
                str = contextEditText.getText().toString();
                textView2.setText(str);

                Log.d("checkDay22", userName + " " + year + " " + month + " " + day + " " + str);
                try {
                    if(textView2.length() == 0) {
                        Toast.makeText(getApplication(), "빈칸을 채워주세요.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_Main.php");
                    String result = request.PhPCalenderUpload(userName, year, month + 1, day, str, change);
                    calendarView.addDecorators(
                            new EventDecorator(Color.RED, Collections.singleton(CalendarDay.from(year, month, day)))//오늘일자에 점 찍
                    );
                    Log.d("checkDay", "되냐");
                    change = 0;


                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }

                time_start.setText("");
                time_end.setText("");

                reset_btn.setVisibility(View.VISIBLE);
                save_Btn.setVisibility(View.INVISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);
                start_time.setVisibility((View.VISIBLE));
                end_time.setVisibility((View.VISIBLE));
                contextEditText.setVisibility(View.INVISIBLE);
                textView2.setVisibility(View.VISIBLE);
                time_end.setVisibility(View.VISIBLE);
                time_start.setVisibility(View.VISIBLE);
                time_set.setVisibility(View.VISIBLE);
            }
        });
        end_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        alarmHour = hourOfDay;
                        alarmMinute = minute;

                        Log.d("checktime1", userName + " " + year + " " + month + " " + day + " " + str + " " + hourOfDay);
                        try {
                            PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_UploadEndtime.php");
                            String result = request.PhPCalenderEndTimeupload(userName, year, month + 1, day, str, alarmHour, alarmMinute);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }

                        try {
                            PHPRequest requestGetName = new PHPRequest("http://133.186.229.67/Calender_GetEndtime.php");
                            String hour = requestGetName.PhPCalenderEndTimeGet(userName, year, month + 1, day, str, alarmHour, alarmMinute);
                            JSONArray jarray = new JSONArray(hour);

                            JSONObject jObject = jarray.getJSONObject(0);
                            int datahour = jObject.getInt("end_time");
                            int datamin = jObject.getInt("end_time_min");

                            if (datahour / 10 == 0 && datamin / 10 == 0)
                                time_end.setText("0" + datahour + " : " + "0" + datamin);
                            else if (datahour / 10 == 0 && datamin / 10 != 0)
                                time_end.setText("0" + datahour + " : " + datamin);
                            else if (datahour / 10 != 0 && datamin / 10 == 0)
                                time_end.setText("" + datahour + " : " + "0" + datamin);
                            else
                                time_end.setText("" + datahour + " : " + datamin);


                        } catch (MalformedURLException | JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, alarmHour, alarmMinute, false);
                timePickerDialog.show();
            }
        });

        start_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        alarmHour = hourOfDay;
                        alarmMinute = minute;

                        Log.d("checktime1", userName + " " + year + " " + month + " " + day + " " + str + " " + hourOfDay);
                        try {
                            PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_UploadStarttime.php");
                            String result = request.PhPCalenderStartTimeupload(userName, year, month + 1, day, str, alarmHour, alarmMinute);
                            Log.d("CHECKTIME", "되냐");
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }


                        try {
                            PHPRequest requestGetName = new PHPRequest("http://133.186.229.67/Calender_GetStarttime.php");
                            String hour = requestGetName.PhPCalenderStartTimeGet(userName, year, month + 1, day, str, alarmHour, alarmMinute);
                            JSONArray jarray = new JSONArray(hour);

                            JSONObject jObject = jarray.getJSONObject(0);
                            int datahour = jObject.getInt("start_time");
                            int datamin = jObject.getInt("start_time_min");

                            if (datahour / 10 == 0 && datamin / 10 == 0)
                                time_start.setText("0" + datahour + " : " + "0" + datamin);
                            else if (datahour / 10 == 0 && datamin / 10 != 0)
                                time_start.setText("0" + datahour + " : " + datamin);
                            else if (datahour / 10 != 0 && datamin / 10 == 0)
                                time_start.setText("" + datahour + " : " + "0" + datamin);
                            else
                                time_start.setText("" + datahour + " : " + datamin);
                        } catch (MalformedURLException | JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, alarmHour, alarmMinute, false);
                timePickerDialog.show();
                Log.d("checktime13", userName + " " + year + " " + month + " " + day + " " + str + " " + alarmHour);

            }
        });

        time_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reset_btn.setVisibility(View.VISIBLE);
                cha_Btn.setVisibility(View.VISIBLE);
                del_Btn.setVisibility(View.VISIBLE);
                time_set.setVisibility(View.INVISIBLE);
                start_time.setVisibility(View.INVISIBLE);
                end_time.setVisibility(View.INVISIBLE);
                time_start.setVisibility(View.INVISIBLE);
                time_end.setVisibility(View.INVISIBLE);
            }
        });
    }

    public void checkDay(int cYear,int cMonth,int cDay){
        Intent intent=getIntent();
        String userName = intent.getStringExtra("userName");
        Log.d("202105241638", String.valueOf(cYear + cMonth + cDay));
        Log.d("202105241638", String.valueOf(cMonth));
        Log.d("202105241638", String.valueOf(cDay));
        Log.d("202105241638", String.valueOf(cYear));
        try {
            Log.d("checkDay","115");
            PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_MainGetDate.php");
            String result = request.PhPCalenderGet(userName,cYear,cMonth+1,cDay);

            JSONArray jarry2 = new JSONArray(result);
            JSONObject jObject2 = jarry2.getJSONObject(0);

            String Cal_content = jObject2.getString("Content");
            int shour = jObject2.getInt("start_time");
            int smin = jObject2.getInt("start_time_min");
            int ehour = jObject2.getInt("end_time");
            int emin = jObject2.getInt("end_time_min");

            if(result.equals("[]")) {
                result = null;
            }

            str =  Cal_content;
            contextEditText.setVisibility(View.INVISIBLE);//edittext 받는거
            textView2.setVisibility(View.VISIBLE);
            textView2.setText(shour + ":" + smin + " ~ " + ehour + ":" + emin + "  " + str);//값을 보여주는 text view


            save_Btn.setVisibility(View.INVISIBLE);
            cha_Btn.setVisibility(View.VISIBLE);
            del_Btn.setVisibility(View.VISIBLE);
            reset_btn.setVisibility(View.VISIBLE);
            start_time.setVisibility(View.INVISIBLE);
            end_time.setVisibility(View.INVISIBLE);
            time_start.setVisibility(View.INVISIBLE);
            time_end.setVisibility(View.INVISIBLE);
            time_set.setVisibility(View.INVISIBLE);

            cha_Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    contextEditText.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.INVISIBLE);
                    contextEditText.setText(str);

                    try {
                        PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_Maincha.php");
                        request.PhPCalenderCha(userName,cYear,cMonth+1,cDay,str);
                        Log.d("chabtn", cMonth+ " " + str);
                        change = 1;
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    time_start.setText("");
                    time_end.setText("");

                    reset_btn.setVisibility(View.VISIBLE);
                    contextEditText.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.INVISIBLE);
                    contextEditText.setText(str);

                    save_Btn.setVisibility(View.VISIBLE);
                    cha_Btn.setVisibility(View.INVISIBLE);
                    del_Btn.setVisibility(View.INVISIBLE);
                    textView2.setText(contextEditText.getText());
                }

            });
            del_Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    textView2.setVisibility(View.INVISIBLE);
                    contextEditText.setText("");
                    try {
                        PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_Maindel.php");
                        request.PhPCalenderDel(userName,cYear,cMonth+1,cDay,str);
                        Log.d("delbtn", cMonth+ " " + str);
                        calendarView.addDecorators(
                                new EventDecorator(0xFFFEE7E6, Collections.singleton(CalendarDay.from(cYear, cMonth,cDay)))//오늘일자에 점 찍
                        );//8자리에서 앞에 2자리는 투명도
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    textView2.setVisibility(View.INVISIBLE);
                    contextEditText.setText("");
                    contextEditText.setVisibility(View.VISIBLE);
                    save_Btn.setVisibility(View.VISIBLE);
                    cha_Btn.setVisibility(View.INVISIBLE);
                    del_Btn.setVisibility(View.INVISIBLE);
                    reset_btn.setVisibility(View.VISIBLE);

                }
            });
            if(result == null){
                textView2.setVisibility(View.INVISIBLE);
                diaryTextView.setVisibility(View.VISIBLE);
                save_Btn.setVisibility(View.VISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);
                contextEditText.setVisibility(View.VISIBLE);
                reset_btn.setVisibility(View.VISIBLE);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

        public void anim() {

            if (isBtnOpen) {
                MovetoBoard.startAnimation(btn_close);
                MovetoPersonal.startAnimation(btn_close);
                MovetoOpen.startAnimation(btn_close);
                MovetoBoard.setClickable(false);
                MovetoPersonal.setClickable(false);
                MovetoOpen.setClickable(false);
                isBtnOpen = false;
            }

            else {
                MovetoBoard.startAnimation(btn_open);
                MovetoPersonal.startAnimation(btn_open);
                MovetoOpen.startAnimation(btn_open);
                MovetoBoard.setClickable(true);
                MovetoPersonal.setClickable(true);
                MovetoOpen.setClickable(true);
                isBtnOpen = true;
            }
        }

        @Override
        public void onClick(View v) {
            Intent intent = getIntent();
            String userName = intent.getStringExtra("userName");
            int id = v.getId();
            switch (id) {
                case R.id.OpenBtnList:
                    anim();
                    break;
                case R.id.MovetoBoard:
                    anim();
                    Intent intent1 = new Intent(MainActivity.this, Noticeboard.class);
                    intent1.putExtra("userName",userName);
                    startActivity(intent1);
                    Toast.makeText(this, "게시판", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.MovetoPersonal:
                    anim();
                    Toast.makeText(this, "개인 일정 화면", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.MovetoOpen:
                    anim();
                    Intent intent2 = new Intent(MainActivity.this, GetOthercalActivity.class);
                    intent2.putExtra("userName",userName);
                    Log.d("Main_username", userName);
                    startActivity(intent2);
                    Toast.makeText(this, "공유 일정 화면", Toast.LENGTH_SHORT).show();
                    break;
            }
        }

}
