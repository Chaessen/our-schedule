package com.example.open_calander_junkyu_java3;
//우석이꺼
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.sql.Timestamp;

import androidx.appcompat.app.AppCompatActivity;

import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UploadNoticeboard extends AppCompatActivity {

    long now = System.currentTimeMillis();
    Date mDate = new Date(now);
    SimpleDateFormat simpleDate = new SimpleDateFormat("yy-MM-dd hh:mm:ss");
    String getTime = simpleDate.format(mDate);
    //시간 string 형식으로 답아오는거

    private EditText Title, Content;
    private Button btn_Upload;
    private String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent=getIntent();
        String userName = intent.getStringExtra("userName");
        // writer값 받은거
        int Createitem = intent.getIntExtra("Createitem" , 0);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contentwrite);
        NetworkUtil.setNetworkPolicy();

    Title = (EditText) findViewById(R.id.NoticeBoard_Title);
    Content = (EditText) findViewById(R.id.NoticeBoard_Content);
    btn_Upload = (Button) findViewById(R.id.NoticeBoard_Uploadbtn);

        btn_Upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Log.d("strresult", "result3333:");
                    if(Title.length() == 0 || Content.length() == 0) {
                        // String일 경우 .trim() 바로 가능
                        Toast.makeText(getApplication(), "빈칸을 채워주세요.", Toast.LENGTH_SHORT).show();
                        Log.d("#", "title"+ Title.length() + "Content" + Content.length());
                        return;
                    }
                    else {
                        Log.d("strresult", "result444444:");
                        PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_Notice.php");
                        String result = request.PHPNoticeUpload(String.valueOf(Content.getText()),getTime, userName,String.valueOf(Title.getText()));
                        Log.d("strresult", "result22:" + result);
                        if (result.equals("ok")) {
                            Toast.makeText(getApplication(), "게시판", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(UploadNoticeboard.this, Noticeboard.class);
                            intent.putExtra("content",String.valueOf(Content.getText()));// 0524 추가
                            intent.putExtra("title",String.valueOf(Title.getText()));// 0524 추가
                            intent.putExtra("timeline",getTime);// 0524 추가
                            intent.putExtra("userName",userName);// 0524 추가
                            intent.putExtra("Createitem",1);// 버튼이 눌렷다는것을 알림

                            startActivity(intent);
                        } else {
                            Toast.makeText(getApplication(), "다시 입력해주세요.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }catch (MalformedURLException e){
                    e.printStackTrace();
                }
            }
        });
    }
}