package com.example.open_calander_junkyu_java3;


import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.MalformedURLException;
import java.util.ArrayList;


public class MyListAdapter extends BaseAdapter implements View.OnClickListener {
    public MyListAdapter(Context context, ArrayList<list_item> list_itemArrayList,ListBtnClickListener clickListener) {
        this.context = context;
        this.list_itemArrayList = list_itemArrayList;
        this.listBtnClickListener = clickListener ;

    }

    public interface ListBtnClickListener {
        void onListBtnClick(int position);
    }
    private ListBtnClickListener listBtnClickListener;
    int resourceId ;
    // 생성자로부터 전달된 ListBtnClickListener  저장.


    Context context;
    ArrayList<list_item> list_itemArrayList;


    TextView nickname_textView;
    TextView title_textView;
    TextView date_textView;
    TextView content_textView;
    ImageView profile_imageView;
    Button notice_btn;

    @Override
    public int getCount() {
        return this.list_itemArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return this.list_itemArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position ;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.noticeinfo, null);
            nickname_textView = (TextView) convertView.findViewById(R.id.nickname_textview);
            content_textView = (TextView) convertView.findViewById(R.id.content_textview);
            date_textView = (TextView) convertView.findViewById(R.id.date_textview);
            title_textView = (TextView) convertView.findViewById(R.id.title_textView);
            profile_imageView = (ImageView) convertView.findViewById(R.id.profile_imageview);

        }

        nickname_textView.setText(list_itemArrayList.get(position).getNickname());
        title_textView.setText(list_itemArrayList.get(position).getTitle());
        content_textView.setText(list_itemArrayList.get(position).getContent());
        date_textView.setText(list_itemArrayList.get(position).getWrite_date());
        profile_imageView.setImageResource(list_itemArrayList.get(position).getProfile_image());

        notice_btn = (Button) convertView.findViewById(R.id.btn_notice);
        notice_btn.setTag(position);
        notice_btn.setOnClickListener(this);
        return convertView;
    }

    @Override
    public void onClick(View v) {
        Log.d("noticebutton2", "why?");
        if (this.listBtnClickListener != null) {
            this.listBtnClickListener.onListBtnClick((int)v.getTag());
        }
    }
}