package com.example.open_calander_junkyu_java3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;


public class LoginActivity extends AppCompatActivity {
    private EditText login_ID, login_PW;
    private Button btn_login, btn_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        NetworkUtil.setNetworkPolicy();

        login_ID = (EditText)findViewById(R.id.login_etID);
        login_PW = (EditText)findViewById(R.id.login_etPW);
        btn_login = (Button)findViewById(R.id.login_btLogin);
        btn_register = (Button)findViewById(R.id.login_btRegister);

        login_ID.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) && keyCode == KeyEvent.KEYCODE_ENTER) {
                    //EditText editText = (EditText) findViewById(R.id.login_pw_edit);
                    login_PW.requestFocus();
                    return true;
                }
                return false;
            }
        });

        login_PW.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) && keyCode == KeyEvent.KEYCODE_ENTER) {
                    btn_login.performClick();
                    return true;
                }
                return false;
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(login_ID.length() == 0 || login_PW.length() == 0) {
                        Toast.makeText(getApplication(), "빈칸을 채워주세요.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    PHPRequest request = new PHPRequest("http://133.186.229.67/Calander_Login.php");
                    String result = request.PhPlogin(String.valueOf(login_ID.getText()), String.valueOf(login_PW.getText()));

                    PHPRequest requestGetName = new PHPRequest("http://133.186.229.67/Calender_Getname.php");
                    String Myname =  requestGetName.PhPgetname(String.valueOf(login_ID.getText()));

                    JSONArray jarray = new JSONArray(Myname);

                    JSONObject jObject = jarray.getJSONObject(0);
                    String name = jObject.getString("Name");


                    if(result.equals("ok")){
                        Toast.makeText(getApplication(), "로그인 성공", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.putExtra("userName",name);//05240951 추가

                        startActivity(intent);
                        }
                    else{
                        Toast.makeText(getApplication(), "입력정보 오류!", Toast.LENGTH_SHORT).show();
                    }
                }catch (MalformedURLException | JSONException e) {
                    e.printStackTrace();

                }
            }
        }
        );
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplication(), "회원가입 화면으로 이동합니다", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}