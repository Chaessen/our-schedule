package com.example.open_calander_junkyu_java3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.net.MalformedURLException;

public class GetOthercalActivity extends AppCompatActivity implements View.OnClickListener {

    public Button btn_getdata;
    public EditText getID;
    private Animation btn_open, btn_close;
    private Boolean isBtnOpen = false;
    private FloatingActionButton OpenBtnList, MovetoBoard, MovetoPersonal, MovetoOpen;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent intent=getIntent();
            String userID = intent.getStringExtra("userName");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getcal);

        getID = findViewById(R.id.getData);
        btn_getdata = findViewById(R.id.btn_getdata);

        btn_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.openbutton);
        btn_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.closebutton);
        OpenBtnList = (FloatingActionButton) findViewById(R.id.OpenBtnList);
        MovetoBoard = (FloatingActionButton) findViewById(R.id.MovetoBoard);
        MovetoPersonal = (FloatingActionButton) findViewById(R.id.MovetoPersonal);
        MovetoOpen = (FloatingActionButton) findViewById(R.id.MovetoOpen);


        OpenBtnList.setOnClickListener(this);
        MovetoBoard.setOnClickListener(this);
        MovetoPersonal.setOnClickListener(this);
        MovetoOpen.setOnClickListener(this);

        btn_getdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                {
                    try {
                        if(getID.length() == 0) {
                            Toast.makeText(getApplication(), "빈칸을 채워주세요.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        Log.d("getdate",String.valueOf(getID.getText()) + userID );
                        PHPRequest request = new PHPRequest("http://133.186.229.67/GetotherCal.php");
                        request.PhPGetotherCal(String.valueOf(getID.getText()),userID);
                        Intent intent = new Intent(GetOthercalActivity.this, MainActivity.class);
                        intent.putExtra("userName",userID);// 0529 추가
                        startActivity(intent);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

    }
    public void anim() {

        if (isBtnOpen) {
            MovetoBoard.startAnimation(btn_close);
            MovetoPersonal.startAnimation(btn_close);
            MovetoOpen.startAnimation(btn_close);
            MovetoBoard.setClickable(false);
            MovetoPersonal.setClickable(false);
            MovetoOpen.setClickable(false);
            isBtnOpen = false;
        }

        else {
            MovetoBoard.startAnimation(btn_open);
            MovetoPersonal.startAnimation(btn_open);
            MovetoOpen.startAnimation(btn_open);
            MovetoBoard.setClickable(true);
            MovetoPersonal.setClickable(true);
            MovetoOpen.setClickable(true);
            isBtnOpen = true;
        }
    }

    @Override
    public void onClick(View v) {
        Intent intent = getIntent();
        String userName = intent.getStringExtra("userName");
        int id = v.getId();
        switch (id) {
            case R.id.OpenBtnList:
                anim();
                // Toast.makeText(this, "Open Button List", Toast.LENGTH_SHORT).show();
                break;
            case R.id.MovetoBoard:
                anim();
                Intent intent1 = new Intent(GetOthercalActivity.this, Noticeboard.class);
                intent1.putExtra("userName",userName);// 0529 추가
                startActivity(intent1);
                Toast.makeText(this, "게시판", Toast.LENGTH_SHORT).show();
                break;
            case R.id.MovetoPersonal:
                anim();
                Intent intent2 = new Intent(GetOthercalActivity.this, MainActivity.class);
                intent2.putExtra("userName",userName);// 0529 추가
                startActivity(intent2);
                Toast.makeText(this, "개인 일정 화면", Toast.LENGTH_SHORT).show();
                break;
            case R.id.MovetoOpen:
                anim();
                Toast.makeText(this, "공유 일정 화면", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}