package com.example.open_calander_junkyu_java3;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.prolificinteractive.materialcalendarview.CalendarDay;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Date;

import static java.lang.System.currentTimeMillis;

public class Noticeboard extends AppCompatActivity implements View.OnClickListener, MyListAdapter.ListBtnClickListener {
    ListView listView;
    MyListAdapter myListAdapter;
    private  Button btn_Upload;
    ArrayList<list_item> list_itemArrayList;
    private View convertView;

    private Animation btn_open, btn_close;
    private Boolean isBtnOpen = false;
    private FloatingActionButton OpenBtnList, MovetoBoard, MovetoPersonal, MovetoOpen;


    public static class Code {
        public static int requestCode =100;
        public static  int resultCode = 1;
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        Intent intent = getIntent();
        String userName = intent.getStringExtra("userName");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.noticelist);
        //setContentView(R.layout.contentwrite);
        //     setContentView(R.layoutw.contentwrite);
        listView = (ListView)findViewById(R.id.my_listView);

        btn_Upload = (Button) findViewById(R.id.NoticeBoard_Uploadbtn);


        list_itemArrayList = new ArrayList<list_item>();
        myListAdapter = new MyListAdapter(Noticeboard.this,list_itemArrayList, this);
        listView.setAdapter(myListAdapter);

        btn_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.openbutton);
        btn_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.closebutton);
        OpenBtnList = (FloatingActionButton) findViewById(R.id.OpenBtnList);
        MovetoBoard = (FloatingActionButton) findViewById(R.id.MovetoBoard);
        MovetoPersonal = (FloatingActionButton) findViewById(R.id.MovetoPersonal);
        MovetoOpen = (FloatingActionButton) findViewById(R.id.MovetoOpen);

        OpenBtnList.setOnClickListener(this);
        MovetoBoard.setOnClickListener(this);
        MovetoPersonal.setOnClickListener(this);
        MovetoOpen.setOnClickListener(this);

        try {
            PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_NoticeGet.php");
            String result_date = request.PhPNoticeGet();
            JSONArray Noticearry = new JSONArray(result_date);
            Log.d("pickdot","Noticearry"+ Noticearry );
            for(int i=0; i<Noticearry.length();i++){
                JSONObject NoticeObject = Noticearry.getJSONObject(i);
                String not_name = NoticeObject.getString("writer");
                String not_title = NoticeObject.getString("Title");
                String not_date = NoticeObject.getString("timeline");
                String not_content = NoticeObject.getString("Content");

                list_itemArrayList.add(
                        new list_item(R.drawable.human, not_name, not_title, not_date, not_content));

                Log.d("pickdot", "name : " + not_name);
                Log.d("pickdot", "title : " + not_title);
                Log.d("pickdot", "date : " + not_date);
                Log.d("pickdot", "content : " + not_content);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        myListAdapter.notifyDataSetChanged();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "게시물 작성", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                Intent intent = new Intent(Noticeboard.this, UploadNoticeboard.class);
                intent.putExtra("userName",userName);// 0524 추가

                intent.putExtra("Createitem",0);// 0524 추가
                startActivity(intent);
            }

        });

    }

    @Override
    public void onListBtnClick(int position) {
        String not_name= "";
        String not_title="";
        String not_date="";
        String not_content="";
        Log.d("noticebutton", "why???????");
        try {
            PHPRequest request = new PHPRequest("http://133.186.229.67/Calender_NoticeGet.php");
            String result_date = request.PhPNoticeGet();
            JSONArray Noticearry = new JSONArray(result_date);
            Log.d("pickdot","Noticearry"+ Noticearry );
            JSONObject NoticeObject = Noticearry.getJSONObject(position);
            not_name = NoticeObject.getString("writer");
            not_title = NoticeObject.getString("Title");
            not_date = NoticeObject.getString("timeline");
            not_content = NoticeObject.getString("Content");

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent(Noticeboard.this, NoticeActivity.class);
        intent.putExtra("userName",not_name);// 0524 추가
        intent.putExtra("content",not_content);// 0524 추가
        intent.putExtra("title",not_title);// 0524 추가
        intent.putExtra("timeline",not_date);// 0524 추가
        startActivity(intent);
    }
//    @Override
//    public void onListBtnClick() {
//        Log.d("noticebutton", "why???????");
//        Intent intent = new Intent(Noticeboard.this, NoticeActivity.class);
//        intent.putExtra("userName",userName);// 0524 추가
//        intent.putExtra("content",content);// 0524 추가
//        intent.putExtra("title",title);// 0524 추가
//        intent.putExtra("timeline",timeline);// 0524 추가
//        startActivity(intent);
//    }

    public void anim() {

        if (isBtnOpen) {
            MovetoBoard.startAnimation(btn_close);
            MovetoPersonal.startAnimation(btn_close);
            MovetoOpen.startAnimation(btn_close);
            MovetoBoard.setClickable(false);
            MovetoPersonal.setClickable(false);
            MovetoOpen.setClickable(false);
            isBtnOpen = false;
        }

        else {
            MovetoBoard.startAnimation(btn_open);
            MovetoPersonal.startAnimation(btn_open);
            MovetoOpen.startAnimation(btn_open);
            MovetoBoard.setClickable(true);
            MovetoPersonal.setClickable(true);
            MovetoOpen.setClickable(true);
            isBtnOpen = true;
        }
    }

    @Override
    public void onClick(View v) {
        Intent intent = getIntent();
        String userName = intent.getStringExtra("userName");
        int id = v.getId();
        switch (id) {
            case R.id.OpenBtnList:
                anim();
                // Toast.makeText(this, "Open Button List", Toast.LENGTH_SHORT).show();
                break;
            case R.id.MovetoBoard:
                anim();
                Toast.makeText(this, "게시판", Toast.LENGTH_SHORT).show();
                break;
            case R.id.MovetoPersonal:
                anim();
                Intent intent1 = new Intent(Noticeboard.this, MainActivity.class);
                intent1.putExtra("userName",userName);// 0529 추가
                startActivity(intent1);
                Toast.makeText(this, "개인 일정 화면", Toast.LENGTH_SHORT).show();
                break;
            case R.id.MovetoOpen:
                anim();
                Intent intent2 = new Intent(Noticeboard.this, GetOthercalActivity.class);
                intent2.putExtra("userName",userName);// 0529 추가
                Log.d("Main_username", userName);
                startActivity(intent2);
                Toast.makeText(this, "공유 일정 화면", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}


