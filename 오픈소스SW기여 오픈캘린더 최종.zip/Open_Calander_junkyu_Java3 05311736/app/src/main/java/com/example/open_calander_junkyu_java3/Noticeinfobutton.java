package com.example.open_calander_junkyu_java3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Noticeinfobutton extends AppCompatActivity {
    Button btn_ntc;

    @Override
    protected void onCreate( Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.noticeinfo);

        btn_ntc = findViewById(R.id.btn_notice);
        btn_ntc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("noticebutton", "why?");
                Intent intent = new Intent(Noticeinfobutton.this, Noticeboard.class);
                startActivity(intent);
            }

        });

    }
}
