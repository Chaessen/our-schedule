package com.example.open_calander_junkyu_java3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class NoticeActivity extends AppCompatActivity {

    public TextView Notice_Textview_title;
    public TextView Notice_Textview_timeline;
    public TextView Notice_Textview_content;
    public TextView Notice_Textview_username;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.noticescreen);

        Intent intent = getIntent();
        String content = intent.getStringExtra("content");
        String title = intent.getStringExtra("title");
        String timeline = intent.getStringExtra("timeline");
        String userName = intent.getStringExtra("userName");

        Log.d("plz",content+title+timeline+userName);
        Notice_Textview_title = findViewById(R.id.Notice_Title);
        Notice_Textview_timeline = findViewById(R.id.Notice_time);
        Notice_Textview_content = findViewById(R.id.Notice_content);
        Notice_Textview_username = findViewById(R.id.Notice_name);

        Notice_Textview_title.setText(title);
        Notice_Textview_timeline.setText(timeline);
        Notice_Textview_content.setText(content);
        Notice_Textview_username.setText(userName);
    }
}
